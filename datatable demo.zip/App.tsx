import React, { useState } from "react";
import { InputField } from "./InputField";

export default function App() {
  const [text, setText] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="p-6 max-w-md mx-auto space-y-6">
      <h1 className="text-xl font-bold">InputField Demo</h1>

      <InputField
        label="Username"
        placeholder="Enter your username"
        value={text}
        onChange={(e) => setText(e.target.value)}
        helperText="This will be shown on your profile"
        clearable
        variant="outlined"
        size="md"
      />

      <InputField
        label="Password"
        placeholder="Enter your password"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        errorMessage="Password is required"
        invalid={!password}
        variant="filled"
        size="lg"
        theme="dark"
      />
    </div>
  );
}
