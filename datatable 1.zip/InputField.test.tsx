import { render, screen, fireEvent } from "@testing-library/react";
import { InputField } from "./InputField";

test("renders with label and placeholder", () => {
  render(<InputField label="Name" placeholder="Enter name" />);
  expect(screen.getByLabelText("Name")).toBeInTheDocument();
});

test("clears input when clear button is clicked", () => {
  const handleChange = jest.fn();
  render(
    <InputField
      value="hello"
      onChange={handleChange}
      clearable
      label="Name"
    />
  );
  const clearButton = screen.getByRole("button", { name: /clear input/i });
  fireEvent.click(clearButton);
  expect(handleChange).toHaveBeenCalled();
});
