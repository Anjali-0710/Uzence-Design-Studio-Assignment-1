import { render, screen, fireEvent } from "@testing-library/react";
import { DataTable, Column } from "./DataTable";

interface User {
  id: number;
  name: string;
}

const columns: Column<User>[] = [
  { key: "name", title: "Name", dataIndex: "name", sortable: true },
];

const data: User[] = [
  { id: 1, name: "Alice" },
  { id: 2, name: "Bob" },
];

test("renders data in table", () => {
  render(<DataTable<User> data={data} columns={columns} />);
  expect(screen.getByText("Alice")).toBeInTheDocument();
  expect(screen.getByText("Bob")).toBeInTheDocument();
});

test("selects a row when clicked", () => {
  const onRowSelect = jest.fn();
  render(
    <DataTable<User>
      data={data}
      columns={columns}
      selectable
      onRowSelect={onRowSelect}
    />
  );
  const row = screen.getByText("Alice").closest("tr")!;
  fireEvent.click(row);
  expect(onRowSelect).toHaveBeenCalled();
});
