import React, { useState } from "react";
import clsx from "clsx";

export interface InputFieldProps {
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  label?: string;
  placeholder?: string;
  helperText?: string;
  errorMessage?: string;
  disabled?: boolean;
  invalid?: boolean;
  variant?: "filled" | "outlined" | "ghost";
  size?: "sm" | "md" | "lg";
  type?: "text" | "password";
  clearable?: boolean;
  theme?: "light" | "dark";
}

export const InputField: React.FC<InputFieldProps> = ({
  value = "",
  onChange,
  label,
  placeholder,
  helperText,
  errorMessage,
  disabled = false,
  invalid = false,
  variant = "outlined",
  size = "md",
  type = "text",
  clearable = false,
  theme = "light",
}) => {
  const [showPassword, setShowPassword] = useState(false);

  const inputType = type === "password" && showPassword ? "text" : type;

  return (
    <div
      className={clsx(
        "flex flex-col w-full",
        theme === "dark" ? "text-white" : "text-black"
      )}
    >
      {label && (
        <label className="mb-1 text-sm font-medium" aria-label={label}>
          {label}
        </label>
      )}

      <div
        className={clsx(
          "relative flex items-center rounded-2xl transition border",
          size === "sm" && "text-sm px-2 py-1",
          size === "md" && "text-base px-3 py-2",
          size === "lg" && "text-lg px-4 py-3",
          variant === "outlined" && "border-gray-400",
          variant === "filled" && "bg-gray-200 border-transparent",
          variant === "ghost" && "border-transparent bg-transparent",
          disabled && "opacity-50 cursor-not-allowed",
          invalid && "border-red-500"
        )}
      >
        <input
          type={inputType}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          disabled={disabled}
          aria-invalid={invalid}
          className="flex-1 bg-transparent outline-none"
        />

        {/* Clear Button */}
        {clearable && value && !disabled && (
          <button
            type="button"
            onClick={() => onChange?.({ target: { value: "" } } as any)}
            className="ml-2 text-gray-500 hover:text-gray-700"
            aria-label="Clear input"
          >
            ✕
          </button>
        )}

        {/* Password Toggle */}
        {type === "password" && (
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="ml-2 text-gray-500 hover:text-gray-700"
            aria-label="Toggle password visibility"
          >
            {showPassword ? "🙈" : "👁️"}
          </button>
        )}
      </div>

      {/* Helper/Error Text */}
      {invalid && errorMessage ? (
        <p className="text-sm text-red-500 mt-1">{errorMessage}</p>
      ) : (
        helperText && <p className="text-sm text-gray-500 mt-1">{helperText}</p>
      )}
    </div>
  );
};
