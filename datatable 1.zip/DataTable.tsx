import React, { useState } from "react";
import clsx from "clsx";

export interface Column<T> {
  key: string;
  title: string;
  dataIndex: keyof T;
  sortable?: boolean;
}

export interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  loading?: boolean;
  selectable?: boolean;
  onRowSelect?: (selectedRows: T[]) => void;
}

export function DataTable<T extends { id: string | number }>({
  data,
  columns,
  loading = false,
  selectable = false,
  onRowSelect,
}: DataTableProps<T>) {
  const [sortConfig, setSortConfig] = useState<{
    key: keyof T | null;
    direction: "asc" | "desc";
  }>({ key: null, direction: "asc" });

  const [selectedRows, setSelectedRows] = useState<Set<string | number>>(
    new Set()
  );

  // Sorting logic
  const sortedData = React.useMemo(() => {
    if (!sortConfig.key) return data;
    return [...data].sort((a, b) => {
      const aVal = a[sortConfig.key!];
      const bVal = b[sortConfig.key!];
      if (aVal < bVal) return sortConfig.direction === "asc" ? -1 : 1;
      if (aVal > bVal) return sortConfig.direction === "asc" ? 1 : -1;
      return 0;
    });
  }, [data, sortConfig]);

  const handleSort = (col: Column<T>) => {
    if (!col.sortable) return;
    setSortConfig((prev) => ({
      key: col.dataIndex,
      direction:
        prev.key === col.dataIndex && prev.direction === "asc" ? "desc" : "asc",
    }));
  };

  const toggleRowSelection = (id: string | number) => {
    if (!selectable) return;
    setSelectedRows((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) newSet.delete(id);
      else newSet.add(id);
      const selected = data.filter((row) => newSet.has(row.id));
      onRowSelect?.(selected);
      return newSet;
    });
  };

  if (loading) {
    return <div className="p-4 text-center">Loading...</div>;
  }

  if (!loading && data.length === 0) {
    return <div className="p-4 text-center">No data available</div>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full border-collapse border">
        <thead className="bg-gray-100">
          <tr>
            {selectable && <th className="px-4 py-2"></th>}
            {columns.map((col) => (
              <th
                key={col.key}
                onClick={() => handleSort(col)}
                className={clsx(
                  "px-4 py-2 text-left cursor-pointer select-none",
                  col.sortable && "hover:bg-gray-200"
                )}
                aria-sort={
                  sortConfig.key === col.dataIndex ? sortConfig.direction : "none"
                }
              >
                {col.title}
                {sortConfig.key === col.dataIndex &&
                  (sortConfig.direction === "asc" ? " ↑" : " ↓")}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sortedData.map((row) => (
            <tr
              key={row.id}
              className={clsx(
                "hover:bg-gray-50",
                selectable && selectedRows.has(row.id) && "bg-blue-100"
              )}
              onClick={() => toggleRowSelection(row.id)}
              aria-selected={selectedRows.has(row.id)}
            >
              {selectable && (
                <td className="px-4 py-2">
                  <input
                    type="checkbox"
                    checked={selectedRows.has(row.id)}
                    readOnly
                  />
                </td>
              )}
              {columns.map((col) => (
                <td key={col.key} className="px-4 py-2 border-t">
                  {String(row[col.dataIndex])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
